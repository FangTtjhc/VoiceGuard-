import smtplib
from email.mime.text import MIMEText
from email.header import Header
import os
import datetime

# ====================================================
# ⚠️ 1. 邮件配置 (请替换为您自己的信息) ⚠️
# ====================================================

# --- 发件箱配置 ---
# 示例: 
#   - 腾讯企业邮箱: smtp.exmail.qq.com, 465 (SSL)
#   - 163 邮箱: smtp.163.com, 465 (SSL)
#   - 阿里云企业邮箱: smtp.mxhichina.com, 465 (SSL)
SMTP_SERVER = "smtp.163.com" 
SMTP_PORT = 465                             # 端口号，通常是 465 (SSL)
SENDER_EMAIL = ""    # 您的发件人邮箱
SENDER_PASSWORD = "" # ⚠️ 请务必使用应用专用密码
# ====================================================
# 2. 动态内容邮件发送函数
# ====================================================
TEST_RECIPIENT_EMAIL = ""  #接收对象

def send_test_email_with_record(record_info: str):
    """
    发送包含动态记录信息的邮件，替换 'hello word'。
    :param record_info: 包含记录信息的字符串，将作为邮件正文。
    """
    
    subject = "✅ 新的声纹记录处理完成通知"
    
    # 使用传入的记录信息构建邮件正文
    body = f"尊敬的用户:\n\n以下是声纹记录处理的详细信息:\n\n{record_info}\n\n请查收。"
    
    # 构造邮件对象
    # 邮件类型为纯文本 (plain)，编码为 utf-8
    message = MIMEText(body, 'plain', 'utf-8')
    
    # 极简 From/To 头部设置
    message['From'] = SENDER_EMAIL 
    message['To'] = TEST_RECIPIENT_EMAIL
    message['Subject'] = Header(subject, 'utf-8')
    
    try:
        # 使用 smtplib.SMTP_SSL 建立安全的 SSL 连接
        with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT) as server:
            print(f"\n--- 正在连接 SMTP 服务器... ---")
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            
            print(f"--- 尝试发送记录邮件给 {TEST_RECIPIENT_EMAIL} ---")
            # 注意 sendmail 接收一个列表作为收件人
            server.sendmail(SENDER_EMAIL, [TEST_RECIPIENT_EMAIL], message.as_bytes())
            
            print(f"✅ 邮件发送成功！请检查收件箱。")
            return True
            
    except smtplib.SMTPAuthenticationError:
        print(f"❌ 邮件发送失败: 登录认证失败。请务必使用应用专用密码。")
        return False
    except smtplib.SMTPConnectError:
        print(f"❌ 邮件发送失败: 连接失败。请检查 SMTP 服务器配置和网络。")
        return False
    except Exception as e:
        print(f"❌ 邮件发送失败: 发生未知错误 - {e}")
        return False


if __name__ == '__main__':
    # 示例调用
    test_data = (
        "文件名: test_recording_001.wav\n"
        "用户ID: U20250101\n"
        "比对结果: 注册成功\n"
        "处理时间: 2025-11-11 22:50:00"
    )
    # 请手动取消注释并运行此文件来测试邮件功能
    # send_test_email_with_record(test_data)
    pass