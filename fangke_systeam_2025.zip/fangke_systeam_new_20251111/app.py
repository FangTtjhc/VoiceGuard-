import os
import re
import json
import datetime
import uuid # 新增：用于生成声纹ID
from io import StringIO
import shutil
import numpy as np
import pandas as pd
import librosa
import pydub
from pypinyin import pinyin, Style
# 导入 requests 库进行 LLM API 调用
import requests 
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry 
from flask import Flask, request, render_template_string, redirect, url_for, session, send_file, make_response
from werkzeug.utils import secure_filename
import speech_recognition as sr

# 导入新的邮件发送函数
from email_test import send_test_email_with_record


FFMPEG_BIN_DIR = r'D:\software\ffmpeg' # 这里应该是 D:\software\ffmpeg\bin，但如果您的exe就在 D:\software\ffmpeg 下，请使用它。
                                     # 假设 ffmpeg.exe 就在 D:\software\ffmpeg 目录下。

FFMPEG_EXE_PATH = os.path.join(FFMPEG_BIN_DIR, 'ffmpeg.exe')
FFPROBE_EXE_PATH = os.path.join(FFMPEG_BIN_DIR, 'ffprobe.exe') 

# 假设 FFMPEG_BIN_DIR 是 D:\software\ffmpeg

try:
    print(f"--- 尝试配置 FFmpeg 路径 ---")
    
    # 检查可执行文件是否存在于指定路径
    if not os.path.exists(FFMPEG_EXE_PATH):
        raise FileNotFoundError(f"找不到 ffmpeg.exe: {FFMPEG_EXE_PATH}")
    if not os.path.exists(FFPROBE_EXE_PATH):
        print(f"⚠️ 警告: 找不到 ffprobe.exe，仅配置 ffmpeg.exe。")
        
    # 2. 直接赋值给 pydub 的内部变量，强制它使用该路径
    pydub.AudioSegment.converter = FFMPEG_EXE_PATH
    pydub.AudioSegment.ffprobe = FFPROBE_EXE_PATH
    
    # 3. 同时设置环境变量 (兼容性保障)
    os.environ["FFMPEG_PATH"] = FFMPEG_EXE_PATH
    os.environ["FFPROBE_PATH"] = FFPROBE_EXE_PATH

    print(f"✅ FFmpeg 配置成功！")
    print(f"   FFmpeg 路径: {pydub.AudioSegment.converter}")
    print(f"   FFprobe 路径: {pydub.AudioSegment.ffprobe}")
    
except FileNotFoundError as e:
    print(f"❌ 致命错误：路径配置失败，找不到 FFmpeg/FFprobe 可执行文件！")
    print(f"   请检查您在代码中设置的路径是否正确: {FFMPEG_BIN_DIR}")
    # 退出程序以阻止后续失败
    # sys.exit(1) # 在 Flask app 中不建议直接退出
except Exception as e:
    print(f"❌ 设置 FFmpeg 路径时发生未知错误: {e}")
# ----------------------------------------------------
# 1. Configuration (配置)
# ----------------------------------------------------
app = Flask(__name__)
# 使用固定密钥用于 session 管理 (在生产环境中应使用复杂随机值)
app.secret_key = 'super_secret_key_for_fangke_app' 

# LLM 配置 (使用 requests 库，确保兼容性)
API_KEY = os.environ.get("OPENAI_API_KEY", "")#TODO 此处插入的llm配置
BASE_URL = os.environ.get("BASE_URL", "")
LLM_MODEL = "gpt-4o-mini" # 使用 gpt-4o-mini

# 文件路径配置
UPLOAD_FOLDER = 'uploads'
OUTPUT_DIR = 'output_data'
CSV_FILENAME = 'data_save.csv'

OUTPUT_FILE = os.path.join(OUTPUT_DIR, CSV_FILENAME)

# 声纹系统配置 (使用 JSON 数据库，并修改相关常量)
VOICEPRINT_DB_FILE = 'voiceprint_db.json' # 【新增】JSON 数据库文件
VOICEPRINT_THRESHOLD = 5.0 # 【修改】声纹比对距离阈值
TEMP_STT_FILE = "temp_stt_audio_std.wav" # <-- 使用全局常量代替局部变量

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit

# *** 核心修改点 1: 加入 'webm' 到允许的文件扩展名 ***
ALLOWED_EXTENSIONS = {'txt', 'wav', 'mp3', 'flac', 'm4a', 'webm'}

# ----------------------------------------------------
# 2. LLM Prompt Template (来自 20251111.txt)
# ----------------------------------------------------
LLM_PROMPT_TEMPLATE = """
尊敬的AI助手，请仔细分析以下文本内容，并识别出文中提及的相关访客信息。我需要你提供以下信息：
1. **访客姓名,接待人名字,拜访时间,拜访天数,访客单位,访客电话,接待人电话，访客身份证,访客车牌号,访客车辆类型,访客类型,拜访原因。所有缺失项或空白字段一律用字符 NAN 填充。**
**列名：访客姓名,接待人名字,拜访时间,拜访天数,访客单位,访客电话,接待人电话，访客身份证,访客车牌号,访客车辆类型,访客类型,拜访原因。**


其中车辆类型选择：无、轿车、大巴车、货车、其他
其中访客类型选择：普通拜访、面试对象、意向客户、公司活动、大型营销活动、商会协会、政府参观、企业参观、院校参观、部门活动、入职报到、项目施工人员、其他
访客类型可进行相似选择：如访客只说拜访，则将拜访补充为普通拜访，使用普通拜访输出，如果使面试则补充为面试对象，使用面试对象输出访客类型。车辆类型同理。

其中如有不符合逻辑的，该条信息应视为无效，并用 NAN 填充对应的字段。\r\n其中如不乘车，则车牌号置为 NAN，车辆类型置为 NAN。\r\n其中拜访原因可以尽量宽松，体现访客目的即可。

其中拜访时间年份默认2025年，以标准格式输出。其中拜访天数关系relation里需要修改为数字，如拜访时长天数小于1天，则置数字1，最大只能置数字3，如为缺失或无关字符则置 NAN。

例如，"你好，我是杨伟宁，来自厦门顶刻智链科技有限公司，电话是1885029072，来拜访杨宇欣，这次是来参观的，拜访时间是2025年3月14，11时50分"，返回内容为：
访客姓名,接待人名字,拜访时间,拜访天数,访客单位,访客电话,接待人电话,访客身份证,访客车牌号,访客车辆类型,访客类型,拜访原因
杨伟宁,杨宇欣,2025/3/14 11:50:00,NAN,厦门顶刻智链科技有限公司,1885029072,NAN,NAN,NAN,普通拜访,"来拜访杨宇欣，这次是来参观的"

5. **不要额外输出提示语，直接输出CSV格式的识别结果，包括表头。**
6. **识别结果，以CSV格式输出，包含表头：访客姓名,接待人名字,拜访时间,拜访天数,访客单位,访客电话,接待人电话,访客身份证,访客车牌号,访客车辆类型,访客类型,拜访原因。**

现在，请分析以下文本内容：

[在这里插入待分析的文本内容]
"""
# 定义 LLM 期望返回的所有列名
REQUIRED_LLM_COLS = ['访客姓名', '接待人名字', '拜访时间', '拜访天数', '访客单位', '访客电话', '接待人电话', '访客身份证', '访客车牌号', '访客车辆类型', '访客类型', '拜访原因']


# ----------------------------------------------------
# 3. Voiceprint Utility Functions (声纹核心工具函数)
# ----------------------------------------------------
import subprocess # 确保在文件顶部导入了

# --- Voiceprint DB Utilities (新增/修改) ---
def load_voiceprint_db():
    """加载声纹数据库 (features, id, full_data)"""
    if os.path.exists(VOICEPRINT_DB_FILE):
        try:
            with open(VOICEPRINT_DB_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError:
            print(f"警告: {VOICEPRINT_DB_FILE} 文件内容损坏，将重新初始化。")
            return []
    return []

def save_voiceprint_db(db):
    """保存声纹数据库"""
    with open(VOICEPRINT_DB_FILE, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False, indent=4)
        
def generate_voiceprint_id():
    """生成一个唯一的声纹ID"""
    return f"VP_{uuid.uuid4().hex[:12].upper()}"

def save_voiceprint_data(vp_id, mfcc_features, full_data_dict):
    """保存或更新声纹ID对应的MFCC特征和完整表单数据"""
    db = load_voiceprint_db()
    
    # 确保 mfcc_features 是 list 类型，方便 JSON 序列化
    mfcc_list = np.array(mfcc_features).tolist() 
    
    new_entry = {
        "voiceprint_id": vp_id,
        "mfcc_features": mfcc_list,
        "full_data": full_data_dict, # 存储完整的修正数据
        "timestamp": datetime.datetime.now().isoformat()
    }

    # 检查是否已存在该 ID (更新逻辑)
    for i, entry in enumerate(db):
        if entry['voiceprint_id'] == vp_id:
            db[i] = new_entry
            print(f"--- ⚠️ 声纹记录已更新：{vp_id} ---")
            save_voiceprint_db(db)
            return

    # 如果不存在，则添加 (新访客)
    db.append(new_entry)
    print(f"--- ✅ 新声纹记录已注册：{vp_id} ---")
    save_voiceprint_db(db)
# --- End Voiceprint DB Utilities ---


def standardize_audio(input_path, output_path):
    """
    【修复后】使用 subprocess 直接调用 FFmpeg，将音频文件转换为声纹专用的标准化格式
    (16kHz, Mono, WAV)。避免 pydub 在 Flask 环境中查找 FFmpeg 失败的问题。
    """
    if not os.path.exists(input_path):
        print(f"标准化失败: 输入文件不存在 {input_path}")
        return None
        
    try:
        print(f"--- 🚀 声纹绕过 pydub：直接调用 FFmpeg 进行声纹转换 ---")
        
        # 构造 FFmpeg 转换命令 (与 STT 转换参数相同)
        command = [
            FFMPEG_EXE_PATH, # 使用顶部配置的绝对路径
            '-i', input_path, 
            '-ac', '1',        # 单声道
            '-ar', '16000',    # 采样率 16000 Hz
            '-y', output_path 
        ]

        # 执行 FFmpeg 命令
        subprocess.run(
            command,
            check=True,  # 如果失败则抛出异常
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding='utf-8',
            shell=True 
        )
        
        if os.path.exists(output_path):
            print(f"--- ✅ 声纹 FFmpeg 转换成功: {input_path} -> {output_path} ---")
            return output_path
        else:
            print("【标准化错误】FFmpeg 执行完毕，但未生成声纹目标文件。")
            return None

    except subprocess.CalledProcessError as e:
        print("❌ 音频标准化失败 (声纹): FFmpeg 命令执行失败。")
        print("FFmpeg 错误输出:\n", e.stderr)
        return None
    
    except Exception as e:
        print(f"❌ 音频标准化失败 (声纹): {e.__class__.__name__}: {e}")
        return None

def extract_mfcc_features(audio_path, n_mfcc=13):
    """
    使用 librosa 提取 MFCC 声纹特征。
    """
    try:
        y, sr = librosa.load(audio_path, sr=16000)
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc)
        mfccs_mean = np.mean(mfccs.T, axis=0)
        return mfccs_mean.tolist()
    except Exception as e:
        print(f"❌ MFCC 特征提取失败: {e}")
        return None

def calculate_euclidean_distance(features_a, features_b):
    """
    计算两个特征向量之间的欧氏距离。
    """
    return np.linalg.norm(np.array(features_a) - np.array(features_b))

def compare_mfcc(features_a, features_b):
    """
    计算两个特征向量之间的欧氏距离。
    """
    arr_a = np.array(features_a) if not isinstance(features_a, np.ndarray) else features_a
    arr_b = np.array(features_b) if not isinstance(features_b, np.ndarray) else features_b
    return np.linalg.norm(arr_a - arr_b)


# 【修改】核心声纹处理逻辑：处理匹配、注册和数据补全
def handle_voiceprint_logic(mfcc_features, current_df):
    """
    执行声纹匹配或注册逻辑，并在匹配成功时自动补全数据。
    
    Args:
        mfcc_features (list): 当前录音的声纹MFCC特征。
        current_df (pd.DataFrame): LLM提取的当前访客数据 (只有一行)。
        
    Returns:
        tuple: (bool is_match_found, pd.DataFrame merged_df, str voiceprint_id, str status_string)
    """
    db = load_voiceprint_db()
    current_mfcc_array = np.array(mfcc_features)
    best_match_id = None
    min_distance = float('inf')
    
    # 1. 尝试匹配
    for entry in db:
        try:
            stored_mfcc = np.array(entry['mfcc_features'])
            distance = compare_mfcc(current_mfcc_array, stored_mfcc)
            
            if distance < min_distance:
                min_distance = distance
                best_match_id = entry['voiceprint_id']
        except Exception as e:
            print(f"匹配过程中出错 (ID: {entry.get('voiceprint_id', 'N/A')}): {e}")
            continue

    current_data = current_df.iloc[0].to_dict()
    
    if best_match_id and min_distance < VOICEPRINT_THRESHOLD:
        # 2. 匹配成功
        status_string = (
            f"声纹验证成功! 匹配到注册声纹 '{best_match_id}'。\n"
            f"   最低距离: {min_distance:.4f} (小于阈值 {VOICEPRINT_THRESHOLD})"
        )
        print(f"--- ✅ {status_string} ---")
        
        # 3. 检索历史数据并合并/补全
        history_entry = next((e for e in db if e['voiceprint_id'] == best_match_id), None)
        
        if history_entry and history_entry.get('full_data'):
            history_data = history_entry['full_data']
            
            # 使用历史数据补全当前数据
            merged_data = current_data.copy()
            for key in history_data.keys():
                current_value = merged_data.get(key)
                # 检查当前值是否缺失 (NaN, None, 或空字符串)
                is_missing = pd.isna(current_value) or str(current_value).strip() == '' or current_value is None
                
                history_value = history_data.get(key)
                is_history_valid = pd.notna(history_value) and str(history_value).strip() != '' and history_value is not None
                
                if is_missing and is_history_valid and key in REQUIRED_LLM_COLS: # 仅补全核心字段
                    merged_data[key] = history_value
                    print(f"   -> 补全字段: {key} (来自声纹历史数据: {history_value})")

            # 将匹配到的ID和最终的DataFrame返回
            merged_df = pd.DataFrame([merged_data])
            merged_df['voiceprint_id'] = best_match_id
            return True, merged_df, best_match_id, status_string
        else:
            # 历史数据丢失，仍然视为匹配，但进入修正流程
            status_string += f"\n--- ⚠️ 警告: 找到声纹ID {best_match_id}，但无法检索到完整历史数据。将进入修正流程。 ---"
            current_df['voiceprint_id'] = best_match_id
            return False, current_df, best_match_id, status_string
            
    else:
        # 4. 匹配失败/新访客：进入注册流程
        new_id = generate_voiceprint_id()
        status_string = (
            f"未匹配到已知声纹 (最低距离 {min_distance:.4f} >= 阈值 {VOICEPRINT_THRESHOLD})。\n"
            f"   已分配新声纹ID: '{new_id}'。"
        )
        print(f"--- ❌ {status_string} ---")
        current_df['voiceprint_id'] = new_id
        return False, current_df, new_id, status_string


# ----------------------------------------------------
# 4. Core Utility Functions (核心工具函数)
# ----------------------------------------------------

def allowed_file(filename):
    """Check if the file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ----------------------------------------------------
# STT 移植代码: 替换 mock_stt
# ----------------------------------------------------

def standardize_audio_for_stt(input_path, output_path):
    """
    使用 subprocess 直接调用 FFmpeg 命令行，将音频文件转换为标准化格式
    (16kHz, Mono, WAV)。彻底绕过 pydub 的内部转换逻辑，解决环境隔离问题。
    """
    import subprocess # 确保 subprocess 可用
    
    if not os.path.exists(input_path):
        print(f"标准化失败: 输入文件不存在 {input_path}")
        return False
        
    try:
        print(f"--- 🚀 STT 绕过 pydub：直接调用 FFmpeg 进行转换 ---")
        
        # 构造 FFmpeg 转换命令
        command = [
            # 使用顶层配置中确认的绝对路径
            FFMPEG_EXE_PATH,
            '-i', input_path,  # 输入文件 (webm)
            '-ac', '1',        # 单声道 (Mono)
            '-ar', '16000',    # 采样率 16000 Hz
            '-y', output_path  # 覆盖输出文件 (wav)
        ]

        # 执行 FFmpeg 命令
        result = subprocess.run(
            command,
            check=True,  # 确保命令成功执行 (返回码为 0)
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            encoding='utf-8',
            # 增加 shell=True 以应对某些 Conda/Windows 环境的 PATH 查找问题
            shell=True 
        )
        
        if os.path.exists(output_path):
            print(f"--- ✅ FFmpeg 转换成功: {input_path} -> {output_path} ---")
            return True
        else:
            print("【标准化错误】FFmpeg 执行完毕，但未生成目标文件。")
            print("FFmpeg 错误输出:\n", result.stderr)
            return False

    except FileNotFoundError:
        # 捕获找不到 FFMPEG_EXE_PATH 本身时抛出的错误
        print(f"🚨 致命错误：找不到 FFmpeg 可执行文件。请检查路径：{FFMPEG_EXE_PATH}")
        return False
    
    except subprocess.CalledProcessError as e:
        # FFmpeg 命令执行失败 (例如：文件损坏)
        print("【标准化错误】FFmpeg 命令执行失败。请检查输入文件。")
        print("FFmpeg 错误输出:\n", e.stderr)
        return False
        
    except Exception as e:
        print(f"【标准化错误】音频标准化发生未知错误: {e.__class__.__name__}: {e}")
        return False

def perform_stt(file_path):
    """
    执行音频标准化和 Google 语音识别。
    """
    print(f"--- 🚀 真实 STT: 正在处理文件 {file_path} ---")
    
    # Standardize the audio first
    if not standardize_audio_for_stt(file_path, TEMP_STT_FILE):
        return f"STT_ERROR: 音频标准化失败，无法进行识别。"

    recognizer = sr.Recognizer()
    try:
        # 使用 sr.AudioFile 读取标准化后的音频数据
        with sr.AudioFile(TEMP_STT_FILE) as source:
            print("--- 正在上传并请求 Google 语音识别服务 ---")
            recognizer.adjust_for_ambient_noise(source) 
            audio_data = recognizer.record(source)
            
            # 使用 Google 识别器，语言代码设置为中文普通话
            text = recognizer.recognize_google(audio_data, language="zh-CN")
            print(f"--- ✅ STT 成功: {text[:50]}... ---")
            return text
            
    except sr.UnknownValueError:
        return "STT_ERROR: Google API 听不懂这段语音（可能是语音太模糊或没有说话）。"
    except sr.RequestError as e:
        return f"STT_ERROR: API 请求失败: 无法连接到 Google 语音识别服务，请检查网络连接；错误详情: {e}"
    except Exception as e:
        return f"STT_ERROR: 发生未知错误: {e}"
    finally:
        # 清理临时文件
        if os.path.exists(TEMP_STT_FILE):
            os.remove(TEMP_STT_FILE)

# ... (clean_llm_output, call_llm_for_extraction, get_pinyin_name 保持不变) ...

def clean_llm_output(output_string):
    """Removes potential Markdown code block markers."""
    lines = output_string.strip().split('\n')
    if lines and lines[0].strip().startswith('```'):
        lines.pop(0)
    if lines and lines[-1].strip().startswith('```'):
        lines.pop(-1)
    return '\n'.join(line.strip() for line in lines if line.strip())

def call_llm_for_extraction(data_content):
    """
    Calls the LLM API to extract structured data using requests.
    Adds a retry mechanism to handle transient network/SSL errors.
    Returns the cleaned CSV string from the LLM.
    """
    api_url = f"{BASE_URL}/chat/completions"
    
    session = requests.Session()
    retry_strategy = Retry(
        total=3, 
        backoff_factor=1.0,  
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["POST"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("https://", adapter)

    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    final_prompt = LLM_PROMPT_TEMPLATE.replace("[在这里插入待分析的文本内容]", data_content)
    
    payload = {
        "model": LLM_MODEL,
        "messages": [{"role": "user", "content": final_prompt}],
        "temperature": 0.0,
    }
    
    try:
        response = session.post(
            api_url, 
            headers=headers, 
            json=payload, 
            timeout=45,
        )
        
        response.raise_for_status() 
        
        data = response.json()
        
        if not data.get('choices') or not data['choices'][0].get('message') or not data['choices'][0]['message'].get('content'):
            print("❌ LLM API 警告: API 调用成功 (HTTP 200)，但模型未返回可用的 content (可能是内容被过滤)。")
            return "LLM_API_ERROR: API 调用成功，但模型未返回任何 content (可能是内容被过滤)。"

        llm_output_csv_string = data['choices'][0]['message']['content']
        return clean_llm_output(llm_output_csv_string)

    except requests.exceptions.RequestException as e:
        error_msg = f"LLM_API_ERROR: API 调用失败 ({e.__class__.__name__}): {e}"
        print(error_msg)
        return error_msg
    except Exception as e:
        error_msg = f"LLM_API_ERROR: 发生未知错误: {e}"
        print(error_msg)
        return error_msg

def get_pinyin_name(name):
    """Helper to convert Chinese name to Pinyin string."""
    if pd.isna(name): return None
    try:
        name_str = str(name).split('(')[0].strip()
        pinyin_list = pinyin(name_str, style=Style.TONE)
        pinyin_str = ''.join([item[0] for item in pinyin_list]) 
        return pinyin_str
    except:
        return None

def process_and_validate_data(csv_string):
    """
    Converts CSV to DataFrame, performs validation, Pinyin conversion, and prepares for saving.
    Returns: DataFrame, error_count, validation_log, visitor_pinyin
    """
    validation_errors = []
    visitor_pinyin = None
    
    # 1. Read CSV and handle NaNs
    try:
        df = pd.read_csv(StringIO(csv_string), sep=',')
        df.columns = df.columns.str.strip() 
        
    except pd.errors.ParserError as e:
        try:
            df = pd.read_csv(StringIO(csv_string), sep=',', names=REQUIRED_LLM_COLS, header=0, on_bad_lines='skip')
            validation_errors.append("警告: LLM 返回的 CSV 格式最初不匹配，已尝试强制使用预定义表头解析。")
        except Exception as inner_e:
            return None, 99, [f"致命错误: 无法解析LLM返回的CSV字符串: {e} / 尝试修复失败: {inner_e}"], visitor_pinyin

    for col in REQUIRED_LLM_COLS:
        if col not in df.columns:
            df[col] = pd.NA
            validation_errors.append(f"警告: LLM 返回的 CSV 缺少关键列 '{col}'，已补齐为 NA。")
            
    df = df.reindex(columns=REQUIRED_LLM_COLS)

    df = df.replace(['0', 0, 'NAN', 'nan', 'NULL', 'null', ''], pd.NA)

    # 2. Data Validation
    def validate_id_and_log(row_index, id_num):
        if pd.isna(id_num): return pd.NA
        id_num_str = str(id_num).strip().replace('"', '').replace("'", "")
        if not (len(id_num_str) == 18 and id_num_str.isalnum()):
            validation_errors.append(f"行 {row_index + 1} 身份证号格式错误: '{id_num_str}'。已替换为 NaN。")
            return pd.NA
        return id_num_str

    def validate_phone_and_log(row_index, phone_num):
        if pd.isna(phone_num): return pd.NA
        phone_num_str = str(phone_num).strip().replace('"', '').replace("'", "")
        if not re.match(r'^\d{8,11}$', phone_num_str):
            validation_errors.append(f"行 {row_index + 1} 电话号码格式错误: '{phone_num_str}' (非8-11位数字)。已替换为 NaN。")
            return pd.NA
        return phone_num_str

    if '访客身份证' in df.columns:
        df['访客身份证'] = df.apply(lambda row: validate_id_and_log(row.name, row['访客身份证']), axis=1)
    if '访客电话' in df.columns:
        df['访客电话'] = df.apply(lambda row: validate_phone_and_log(row.name, row['访客电话']), axis=1)
    if '接待人电话' in df.columns:
        df['接待人电话'] = df.apply(lambda row: validate_phone_and_log(row.name, row['接待人电话']), axis=1)

    # 3. Pinyin Enhancement & Extraction for enrollment
    NAME_COLUMNS = ['访客姓名', '接待人名字']
    
    if not df.empty and '访客姓名' in df.columns and pd.notna(df.iloc[0]['访客姓名']):
        visitor_name = df.iloc[0]['访客姓名']
        visitor_pinyin = get_pinyin_name(visitor_name)
    else:
        visitor_pinyin = 'unknown' 
        
    for col_name in NAME_COLUMNS:
        if col_name in df.columns:
            for index, row in df.iterrows():
                target_name = row[col_name]
                if pd.notna(target_name):
                    try:
                        name_str = str(target_name).split('(')[0].strip()
                        pinyin_list = pinyin(name_str, style=Style.TONE)
                        pinyin_str_display = ' '.join([item[0] for item in pinyin_list])
                        if '(' not in str(target_name): 
                            df.loc[index, col_name] = f"{name_str} ({pinyin_str_display})"
                        else:
                            df.loc[index, col_name] = target_name 
                    except Exception as e:
                        validation_errors.append(f"行 {index + 1} 列 '{col_name}' 拼音转换失败: {e}")

    nan_count = df[REQUIRED_LLM_COLS].isna().sum().sum()
    
    return df, nan_count, validation_errors, visitor_pinyin

def save_to_csv(df):
    """Append DataFrame to the global CSV file."""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    file_exists = os.path.exists(OUTPUT_FILE)
    write_header = not file_exists or (file_exists and os.path.getsize(OUTPUT_FILE) == 0)

    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    df.insert(0, '预约时间', current_time)
        
    final_cols = ['预约时间'] + REQUIRED_LLM_COLS
    df_filtered = df.reindex(columns=final_cols, fill_value=pd.NA)
        
    df_filtered.to_csv(
        OUTPUT_FILE, 
        index=False, 
        mode='a', 
        header=write_header, 
        encoding='utf-8', 
        na_rep='' 
    )
    return f"数据已成功追加保存至 {OUTPUT_FILE}。"

# ----------------------------------------------------
# 5. Flask Routes and Logic (Flask 路由和逻辑)
# ----------------------------------------------------

@app.route('/', methods=['GET'])
def index():
    """Main page with upload form and CSV download link."""
    return render_template_string(INDEX_HTML, csv_file=CSV_FILENAME)

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handles file upload (txt or audio) and redirects to validation/correction."""
    
    extracted_text = ""
    voiceprint_mfcc = None
    file_path = None
    file_ext = None
    
    if 'file' not in request.files:
        session['status'] = '错误: 未选择文件。'
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        session['status'] = '错误: 未选择文件。'
        return redirect(url_for('index'))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        file_ext = filename.rsplit('.', 1)[1].lower()
        
        if file_ext == 'txt':
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    extracted_text = f.read()
            except Exception as e:
                session['status'] = f"错误: 读取文本文件失败: {e}"
                return redirect(url_for('index'))
            finally:
                if os.path.exists(file_path): os.remove(file_path)
                file_path = None
        
        elif file_ext in ['wav', 'mp3', 'flac', 'm4a', 'webm']:
            # 真实 STT 流程：WebM -> 16kHz WAV -> Text
            extracted_text = perform_stt(file_path)
            
            # 增加 STT 错误检查
            if extracted_text.startswith("STT_ERROR"):
                session['status'] = extracted_text
                if os.path.exists(file_path): os.remove(file_path)
                return redirect(url_for('index'))
            # 结束 STT 错误检查
            
            print(f"\n--- 正在标准化和提取音频 ({file_path}) 的声纹特征 ---")
            
            # 声纹流程：WebM -> 16kHz WAV -> MFCC
            # 【修改】使用常量 TEMP_STT_FILE，但为了不冲突，这里使用 temp_verify_audio_std.wav
            temp_verify_file = os.path.join(os.path.dirname(TEMP_STT_FILE), 'temp_verify_audio_std.wav')
            std_verify_path = standardize_audio(file_path, temp_verify_file)
            
            if std_verify_path:
                voiceprint_mfcc = extract_mfcc_features(std_verify_path)
                if os.path.exists(temp_verify_file): os.remove(temp_verify_file)
            
            if voiceprint_mfcc is None:
                print("❌ 声纹特征提取失败，将跳过声纹处理。")
        
        # 核心步骤: 调用 LLM
        llm_csv_string = call_llm_for_extraction(extracted_text)
        
        if llm_csv_string.startswith("LLM_API_ERROR"):
            session['status'] = llm_csv_string
            if file_path and os.path.exists(file_path) and file_ext != 'txt': os.remove(file_path) # 仅清理音频
            return redirect(url_for('index'))
            
        # 核心步骤: 数据处理和校验
        processed_df, nan_count, validation_log, visitor_pinyin = process_and_validate_data(llm_csv_string)

        if processed_df is None or processed_df.empty:
            session['status'] = 'LLM提取失败: 未提取到任何数据行或CSV格式错误。'
            if file_path and os.path.exists(file_path) and file_ext != 'txt': os.remove(file_path)
            return redirect(url_for('index'))
            
        # ----------------------------------------------------------------------
        # 声纹匹配检查 (如果是音频文件)
        # ----------------------------------------------------------------------
        voiceprint_id = None
        voice_match_status_string = "未进行声纹处理"
        is_voice_match = False
        final_processed_df = processed_df.copy() # Start with LLM's raw output

        if voiceprint_mfcc is not None and file_path and os.path.exists(file_path) and file_ext != 'txt':
            
            # 【修改】核心步骤：执行声纹匹配/注册逻辑，并尝试补全数据
            is_voice_match, final_processed_df, voiceprint_id, voice_match_status_string = handle_voiceprint_logic(
                voiceprint_mfcc, 
                processed_df.copy() # 传入 LLM 的原始 DF
            )
            # 【注意】原文件中的 verify_and_enroll_voice 已被删除，旧的声纹文件系统逻辑已移除

        # ----------------------------------------------------------------------
        # 存储最终数据和元数据
        # ----------------------------------------------------------------------
        data_to_correct = final_processed_df.iloc[0].to_dict() # 使用合并后的 DF
        data_to_correct['voiceprint_mfcc'] = voiceprint_mfcc
        data_to_correct['validation_log'] = validation_log
        data_to_correct['visitor_pinyin'] = visitor_pinyin if visitor_pinyin else 'unknown' 
        data_to_correct['original_audio_path'] = file_path if file_ext in ['wav', 'mp3', 'flac', 'm4a', 'webm'] and file_path and os.path.exists(file_path) else None 
        data_to_correct['voiceprint_id'] = voiceprint_id # 【新增】声纹ID
        data_to_correct['voice_match_status'] = voice_match_status_string # 【新增】声纹状态信息

        session['data_to_correct'] = data_to_correct

        # ----------------------------------------------------------------------
        # 业务规则：如果声纹匹配成功，则直接通过，跳过修正步骤
        # ----------------------------------------------------------------------
        if is_voice_match:
            # 匹配成功，数据已自动补全，跳过修正，直接进入保存逻辑
            
            # 1. 注册/更新声纹数据 (使用合并后的数据作为新的“黄金记录”)
            if data_to_correct['voiceprint_id'] and data_to_correct['voiceprint_mfcc']:
                # 清理不必要的字段，准备保存到声纹数据库
                full_data_for_db = {k: v for k, v in data_to_correct.items() if k not in ['voiceprint_mfcc', 'validation_log', 'visitor_pinyin', 'original_audio_path', 'voice_match_status']}
                save_voiceprint_data(
                    data_to_correct['voiceprint_id'], 
                    data_to_correct['voiceprint_mfcc'], 
                    full_data_for_db # 完整的合并后的数据
                )
            
            # 2. 保存到 CSV
            df_to_save = pd.DataFrame([data_to_correct])
            # 清理非 CSV 字段
            df_to_save = df_to_save.drop(columns=['voiceprint_mfcc', 'validation_log', 'visitor_pinyin', 'original_audio_path', 'voice_match_status', 'voiceprint_id'], errors='ignore')
            save_result = save_to_csv(df_to_save)
            
            # 3. 【新增：发送邮件通知】
            # 构造邮件正文所需的记录信息
            last_record_dict = df_to_save.iloc[0].to_dict()
            last_record_dict["声纹处理结果"] = voice_match_status_string # 使用匹配成功状态
            
            # 将字典格式化为纯文本字符串
            record_details_string = "访客登记记录详情:\n"
            for k, v in last_record_dict.items():
                display_value = str(v) if pd.notna(v) else "缺失/NAN"
                record_details_string += f"- {k}: {display_value}\n"
            
            try:
                # 📧 发送邮件通知
                send_test_email_with_record(record_details_string)
                email_status_msg = "且邮件通知已成功发送。"
                print(f"✅ 邮件发送成功。")
            except Exception as e:
                email_status_msg = f"但邮件发送失败: {e}"
                print(f"❌ 邮件发送失败: {e}")

            # 4. 清理文件
            if data_to_correct['original_audio_path'] and os.path.exists(data_to_correct['original_audio_path']):
                os.remove(data_to_correct['original_audio_path'])
                print(f"🧹 已清理上传的原始音频文件: {data_to_correct['original_audio_path']}")
                
            # 5. 设置状态信息 (包含邮件发送结果)
            session['status'] = (
                f'✅ 声纹验证成功，数据已自动补全并保存！\n'
                f'{save_result}\n\n'
                f'📢 声纹处理结果:\n{voice_match_status_string}\n\n'
                f'📧 邮件通知结果: {email_status_msg}'
            )
            # 清理 session 中不再需要的临时数据
            session.pop('data_to_correct', None)
            
            return redirect(url_for('index')) # 成功匹配：直接返回主页

        # 否则 (非匹配成功或匹配但历史数据缺失)，按照原始逻辑处理缺失值
        nan_count = final_processed_df.isna().sum().sum() # 重新计算 nan_count，基于合并后的 DF
        
        if nan_count > 0:
            # 存在 NaN/校验错误，跳转到修正页面
            session['status'] = f'⚠️ 成功提取数据，分配声纹ID: {voiceprint_id}，但发现 {nan_count} 个缺失或不合格字段。请修正后再保存。'
            return redirect(url_for('correct_data'))
        else:
            # 数据完整且校验通过，直接保存
            session['status'] = '✅ 数据完整且校验通过，直接保存。'
            return redirect(url_for('save_data'))

    session['status'] = '错误: 不支持的文件类型。请上传 txt, wav, mp3, flac, m4a, 或 webm 文件。'
    return redirect(url_for('index'))

@app.route('/correct_data', methods=['GET'])
def correct_data():
    """Display the data correction form/modal."""
    data = session.get('data_to_correct')
    
    if data:
        # 清理 data 字典中的 NaN/pd.NA，以便在 HTML 中正确显示空值
        for key, value in data.items():
            # 【修改】修复 pd.isna 对复杂类型（如list）的检查警告
            if key in ['voiceprint_mfcc', 'validation_log']:
                continue 
            try:
                # 检查是否为None/pd.NA/空字符串/NAN字符串
                if pd.isna(value) or value is None or str(value).strip().lower() in ['nan', 'none', 'pd.na', '']:
                    data[key] = ""
            except Exception:
                # 捕获其他异常并设置为 ""
                data[key] = ""
                continue
        
        # 序列化复杂数据结构以便隐藏字段传递
        data['voiceprint_mfcc_json'] = json.dumps(data.get('voiceprint_mfcc'))
        data['validation_log_json'] = json.dumps(data.get('validation_log'))
        data['visitor_pinyin_str'] = data.get('visitor_pinyin', 'unknown')
        data['audio_path_str'] = data.get('original_audio_path', '')
        # 【新增】声纹ID和状态
        data['voiceprint_id_str'] = data.get('voiceprint_id', '') 
        data['voice_match_status_str'] = data.get('voice_match_status', '未进行声纹处理') 
        
    status_message = session.pop('status', '请修正以下访客信息中的缺失或错误字段：')
    
    if not data:
        return redirect(url_for('index'))

    form_fields = {}
    for key, value in data.items():
        if key not in ['voiceprint_mfcc', 'validation_log', 'voiceprint_mfcc_json', 'validation_log_json', 'visitor_pinyin', 'visitor_pinyin_str', 'original_audio_path', 'audio_path_str', 'voiceprint_id', 'voiceprint_id_str', 'voice_match_status', 'voice_match_status_str']:
            display_value = "" if pd.isna(value) else str(value)
            form_fields[key] = display_value
            
    return render_template_string(CORRECTION_HTML, fields=form_fields, data_json=data, status=status_message)

@app.route('/save_data', methods=['GET', 'POST'])
def save_data():
    """
    Final saving step: applies corrections if POST, then saves to CSV and handles voiceprint.
    """
    data = session.pop('data_to_correct', None)
    # 【修改】移除旧的声纹匹配结果逻辑
    # voice_match_result = session.pop('voice_match_result', (None, False)) 
    
    if request.method == 'POST':
        # 从修正表单接收数据
        form_data = {k: request.form.get(k) for k in request.form}
        
        mfcc_json = form_data.get('voiceprint_mfcc_json')
        
        data_aux = {
            # 从隐藏字段解析复杂结构
            'voiceprint_mfcc': json.loads(mfcc_json) if mfcc_json and json.loads(mfcc_json) else None,
            'original_audio_path': form_data.get('audio_path_str', None) or None,
            'visitor_pinyin': form_data.get('visitor_pinyin_str', 'unknown'),
            'validation_log': json.loads(form_data.get('validation_log_json', '[]')), 
            # 【新增】从隐藏字段获取声纹ID和状态
            'voiceprint_id': form_data.get('voiceprint_id_str', None),
            'voice_match_status': form_data.get('voice_match_status_str', '未进行声纹处理'),
        }
        
        # 合并用户修正后的数据
        for key in form_data:
            if key not in ['voiceprint_mfcc_json', 'validation_log_json', 'visitor_pinyin_str', 'audio_path_str', '预约时间', 'voiceprint_id_str', 'voice_match_status_str']:
                 data_aux[key] = form_data[key].strip() or None 
        data = data_aux
        
    if not data:
        session['status'] = '❌ 数据丢失，请重新上传文件。'
        return redirect(url_for('index'))

    # 1. 准备 DataFrame 
    df_to_save = pd.DataFrame([data])
    # 清理非 CSV 字段，【修改】删除声纹ID和状态字段
    df_to_save = df_to_save.drop(columns=['voiceprint_mfcc', 'validation_log', 'visitor_pinyin', 'original_audio_path', 'voice_match_status', 'voiceprint_id'], errors='ignore')
    
    # 2. **声纹注册/更新**
    vp_id = data.get('voiceprint_id')
    mfcc_data = data.get('voiceprint_mfcc')
    voiceprint_status = data.get('voice_match_status', '未进行声纹处理')
    
    # 只有当存在 MFCC 和 ID 时才进行注册/更新 (这适用于非匹配成功的新用户/手动修正的用户)
    if vp_id and mfcc_data:
        # 提取 CSV 需要保存的字段作为完整记录
        full_data_for_db = {k: v for k, v in data.items() if k not in ['voiceprint_mfcc', 'validation_log', 'visitor_pinyin', 'original_audio_path', 'voice_match_status']}
        
        save_voiceprint_data(vp_id, mfcc_data, full_data_for_db)
        
        # 如果是新注册，更新状态信息
        if "已分配新声纹ID" in voiceprint_status:
            voiceprint_status = f"声纹已成功注册/更新为 ID: {vp_id}"
        elif request.method == 'POST':
             # 如果是通过修正页提交，则也更新状态为已注册/更新
             voiceprint_status = f"声纹记录已通过修正页面更新，ID: {vp_id}"
    
    # 3. 保存到 CSV 
    save_result = save_to_csv(df_to_save)
    
    # 4. 【新增：发送邮件通知】
    # 构造邮件正文所需的记录信息
    last_record_dict = df_to_save.iloc[0].to_dict()
    
    # 添加声纹处理结果到记录中
    last_record_dict["声纹处理结果"] = voiceprint_status
    
    # 将字典格式化为纯文本字符串
    record_details_string = "访客登记记录详情:\n"
    for k, v in last_record_dict.items():
        # 替换 pd.NA 为易读的字符串
        display_value = str(v) if pd.notna(v) else "缺失/NAN"
        record_details_string += f"- {k}: {display_value}\n"
    
    try:
        # 📧 发送邮件通知
        send_test_email_with_record(record_details_string)
        email_status_msg = "且邮件通知已成功发送。"
        print(f"✅ 邮件发送成功。")
    except Exception as e:
        email_status_msg = f"但邮件发送失败: {e}"
        print(f"❌ 邮件发送失败: {e}")

    # 5. 清理上传的音频文件
    audio_path = data.get('original_audio_path')
    if audio_path and os.path.exists(audio_path):
        os.remove(audio_path)
        print(f"🧹 已清理上传的原始音频文件: {audio_path}")
        
    session['status'] = f"✅ 操作完成！数据保存成功。\n{save_result}\n\n📢 声纹处理结果:\n{voiceprint_status}\n\n📧 邮件通知结果: {email_status_msg}"
    return redirect(url_for('index'))


@app.route('/download_csv')
def download_csv():
    """Allow downloading the saved CSV file."""
    if not os.path.exists(OUTPUT_FILE):
        return make_response("错误: 目标 CSV 文件不存在。", 404)
        
    try:
        return send_file(
            OUTPUT_FILE, 
            mimetype='text/csv', 
            as_attachment=True, 
            download_name=CSV_FILENAME
        )
    except Exception as e:
        return make_response(f"文件下载失败: {e}", 500)

# ----------------------------------------------------
# 6. HTML Templates (嵌入式 HTML 模板)
# ----------------------------------------------------

INDEX_HTML = """
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>访客信息智能登记系统</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f7f7f7; }
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-top: 4px solid white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .blinking { animation: blinker 1s linear infinite; }
        @keyframes blinker { 50% { opacity: 0.5; } }
    </style>
</head>
<body class="p-4 md:p-8 min-h-screen flex items-start justify-center">
    <div class="w-full max-w-2xl bg-white shadow-xl rounded-xl p-6 md:p-10 space-y-8">
        <h1 class="text-3xl font-extrabold text-gray-900 text-center">访客信息智能登记系统</h1>
        <p class="text-center text-sm text-gray-600">本系统集成了语音识别(STT)、声纹比对/自动注册和LLM信息提取功能。</p>
        
        {% with status = session.pop('status', None) %}
            {% if status %}
                <div id="status-alert" class="p-4 text-sm rounded-lg" role="alert" 
                    style="white-space: pre-wrap; background-color: {% if '错误' in status or '致命错误' in status or 'API 调用失败' in status %}#fef2f2; border: 1px solid #fecaca; color: #b91c1c;{% elif '成功' in status or '已保存' in status or '完成' in status %}#f0fdf4; border: 1px solid #dcfce7; color: #15803d;{% else %}#fffbeb; border: 1px solid #fde68a; color: #b45309;{% endif %}"
                >
                    <div class="font-medium">{{ status }}</div>
                </div>
            {% endif %}
        {% endwith %}

        <form id="upload-form" method="POST" action="{{ url_for('upload_file') }}" enctype="multipart/form-data" class="space-y-6 border-2 border-dashed border-indigo-300 rounded-lg p-6 bg-indigo-50">
            <h2 class="text-xl font-semibold text-indigo-700">步骤 1: 上传或录制访客文件</h2>
            <p class="text-sm text-gray-600">请上传访客登记文本 (.txt) 或带有访客信息的语音文件 (wav/mp3/flac/m4a/**webm**)，**或使用下方录音功能**。</p>
            
            <div id="file-upload-section">
                <label for="file_upload" class="block text-sm font-medium text-gray-700 mb-1">文件上传</label>
                <input type="file" name="file" id="file_upload" 
                    class="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-full file:border-0
                    file:text-sm file:font-semibold
                    file:bg-indigo-50 file:text-indigo-700
                    hover:file:bg-indigo-100"
                    accept=".txt, .wav, .mp3, .flac, .m4a, .webm"
                />
            </div>
            
            <div class="relative flex justify-center items-center">
                <div class="flex-grow border-t border-gray-400"></div>
                <span class="flex-shrink mx-4 text-gray-500 text-sm">或</span>
                <div class="flex-grow border-t border-gray-400"></div>
            </div>

            <div id="recording-section" class="space-y-4 text-center">
                <label class="block text-sm font-medium text-gray-700">麦克风录音</label>
                
                <div id="mic-status" class="text-sm font-semibold text-gray-500">点击麦克风开始录音</div>
                <div id="recording-time" class="text-lg font-mono text-indigo-600 hidden">00:00</div>
                
                <button type="button" id="record-button"
                    class="p-4 rounded-full shadow-lg transition duration-150 ease-in-out bg-red-500 hover:bg-red-600 text-white disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    <svg id="mic-icon" class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path>
                    </svg>
                </button>
                
                <audio id="audio-playback" controls class="w-full mt-2 hidden"></audio>
            </div>
            
            <button type="submit" id="upload-button"
                class="w-full py-2.5 px-4 bg-indigo-600 text-white font-semibold rounded-full shadow-md hover:bg-indigo-700 transition duration-150 ease-in-out disabled:opacity-50"
                disabled
            >
                <span id="button-text">请选择文件或完成录音</span>
                <span id="loading-spinner" class="ml-2 hidden">
                    <span class="spinner"></span>
                </span>
            </button>
            <input type="hidden" name="recorded_audio_filename" id="recorded_audio_filename" value="">
        </form>
        
        <div class="pt-6 border-t border-gray-200 space-y-4">
            <h2 class="text-xl font-semibold text-gray-900">步骤 2: 结果管理</h2>
            <p class="text-sm text-gray-600">所有声纹数据 (.json 文件) 将存放在 **voiceprint_db.json** 文件中。</p>
            <a href="{{ url_for('download_csv') }}"
                class="inline-flex items-center justify-center w-full py-2.5 px-4 bg-green-500 text-white font-semibold rounded-full shadow-md hover:bg-green-600 transition duration-150 ease-in-out"
            >
                下载已保存的 CSV 数据 ({{ csv_file }})
            </a>
            <p class="text-xs text-gray-500 text-center pt-2">访客信息存储在 {{ csv_file }} 中。</p>
        </div>
    </div>
    
    <script>
        const uploadForm = document.getElementById('upload-form');
        const fileInput = document.getElementById('file_upload');
        const recordButton = document.getElementById('record-button');
        const uploadButton = document.getElementById('upload-button');
        const buttonText = document.getElementById('button-text');
        const spinner = document.getElementById('loading-spinner');
        const micStatus = document.getElementById('mic-status');
        const audioPlayback = document.getElementById('audio-playback');
        const recordingTimeDisplay = document.getElementById('recording-time');
        
        // *** 关键设置：前端使用 WebM 格式录制 ***
        const MIME_TYPE = 'audio/webm';
        const FILE_EXTENSION = 'webm';
        
        let mediaRecorder;
        let audioChunks = [];
        let isRecording = false;
        let finalAudioBlob = null;
        let timerInterval;
        let startTime;

        // --- 初始检查：确保浏览器支持 Media API ---
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            micStatus.textContent = '❌ 浏览器不支持麦克风录音功能。请使用 Chrome, Firefox 或新版 Edge。';
            recordButton.disabled = true;
        } else if (!MediaRecorder.isTypeSupported(MIME_TYPE)) {
             micStatus.textContent = `❌ 浏览器不支持 ${MIME_TYPE} 格式录音。`;
             recordButton.disabled = true;
        }
        
        // --- UI 状态更新函数 ---
        function updateUploadButton(isDisabled, text) {
            uploadButton.disabled = isDisabled;
            buttonText.textContent = text;
            if (isDisabled) {
                uploadButton.classList.add('opacity-50');
            } else {
                uploadButton.classList.remove('opacity-50');
            }
        }

        function toggleRecordingUI(recording) {
            isRecording = recording;
            if (recording) {
                recordButton.classList.add('bg-gray-400', 'animate-pulse', 'blinking');
                recordButton.classList.remove('bg-red-500', 'hover:bg-red-600');
                micStatus.textContent = '🔴 正在录音... 点击停止';
                recordingTimeDisplay.classList.remove('hidden');
                updateUploadButton(true, '正在录音，请先停止');
            } else {
                recordButton.classList.remove('bg-gray-400', 'animate-pulse', 'blinking');
                recordButton.classList.add('bg-red-500', 'hover:bg-red-600');
                micStatus.textContent = '点击麦克风开始录音';
                recordingTimeDisplay.classList.add('hidden');
                // 停止后，如果生成了音频文件，则启用上传按钮
                if (finalAudioBlob) {
                    micStatus.textContent = '✅ 录音完成，可回放或重新录制。';
                    updateUploadButton(false, '上传 WebM 录音并开始处理');
                } else if (fileInput.files.length > 0) {
                    updateUploadButton(false, '开始提取、校验与声纹分析');
                } else {
                    updateUploadButton(true, '请选择文件或完成录音');
                }
            }
        }
        
        function formatTime(seconds) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;
            return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
        }
        
        function startTimer() {
            startTime = Date.now();
            recordingTimeDisplay.textContent = '00:00';
            timerInterval = setInterval(() => {
                const elapsed = Math.floor((Date.now() - startTime) / 1000);
                recordingTimeDisplay.textContent = formatTime(elapsed);
            }, 1000);
        }

        function stopTimer() {
            clearInterval(timerInterval);
        }

        // --- MediaRecorder 核心逻辑 ---

        recordButton.addEventListener('click', () => {
            if (isRecording) {
                // 停止录音
                recordButton.disabled = true; // 正在处理中
                mediaRecorder.stop();
                stopTimer();
            } else {
                // 开始录音
                navigator.mediaDevices.getUserMedia({ audio: true })
                    .then(stream => {
                        // 禁用文件上传
                        fileInput.disabled = true; 
                        fileInput.value = '';
                        audioPlayback.classList.add('hidden');
                        finalAudioBlob = null;

                        mediaRecorder = new MediaRecorder(stream, { mimeType: MIME_TYPE });
                        audioChunks = [];

                        mediaRecorder.ondataavailable = event => {
                            audioChunks.push(event.data);
                        };

                        mediaRecorder.onstop = () => {
                            // 最终的 Blob 格式为 WebM
                            const audioBlob = new Blob(audioChunks, { type: MIME_TYPE });
                            finalAudioBlob = audioBlob;
                            
                            stream.getTracks().forEach(track => track.stop());
                            
                            const audioUrl = URL.createObjectURL(audioBlob);
                            audioPlayback.src = audioUrl;
                            audioPlayback.classList.remove('hidden');
                            
                            recordButton.disabled = false;
                            toggleRecordingUI(false); // 停止录音状态
                            
                            // 启用文件上传
                            fileInput.disabled = false; 
                        };

                        mediaRecorder.start();
                        startTimer();
                        toggleRecordingUI(true);

                    }).catch(error => {
                        let errorMsg = '❌ 无法访问麦克风。';
                        if (error.name === 'NotAllowedError' || error.name === 'SecurityError') {
                            errorMsg += '请检查：1. 浏览器权限是否被拒绝；2. 网页是否通过 HTTPS 或 localhost 访问。';
                        } else if (error.name === 'NotFoundError') {
                            errorMsg += '未找到麦克风设备。';
                        } else {
                             errorMsg += `错误类型: ${error.name}`;
                        }
                        micStatus.textContent = errorMsg;
                        console.error('麦克风访问失败:', error);
                        toggleRecordingUI(false);
                        updateUploadButton(true, '请选择文件或完成录音');
                    });
            }
        });
        
        // --- 文件和录音互斥逻辑 ---
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                // 如果用户选择了文件，则清除录音状态
                finalAudioBlob = null;
                audioPlayback.classList.add('hidden');
                updateUploadButton(false, '开始提取、校验与声纹分析');
            } else if (finalAudioBlob) {
                 // 如果取消了文件选择，但有录音，则保持录音状态
                 updateUploadButton(false, '上传 WebM 录音并开始处理');
            } else {
                 updateUploadButton(true, '请选择文件或完成录音');
            }
        });
        
        // --- 提交表单逻辑 ---
        uploadForm.addEventListener('submit', function(event) {
            
            if (fileInput.files.length === 0 && finalAudioBlob === null) {
                alert('请选择一个文件或录制一段访客信息。');
                event.preventDefault();
                return;
            }
            
            updateUploadButton(true, '正在处理中... 请稍候');
            spinner.classList.remove('hidden');

            if (finalAudioBlob) {
                event.preventDefault();
                
                const formData = new FormData();
                // *** 关键：以 WebM 格式文件名提交，让后端处理 WebM -> WAV 的转换 ***
                const date = new Date().toISOString().replace(/[:.]/g, '-');
                const filename = `recorded_audio_${date}.${FILE_EXTENSION}`;
                formData.append('file', finalAudioBlob, filename);
                
                fetch('{{ url_for("upload_file") }}', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(html => {
                    const tempDoc = new DOMParser().parseFromString(html, 'text/html');
                    const metaRedirect = tempDoc.querySelector('meta[http-equiv="refresh"]');
                    
                    if (metaRedirect) {
                        const content = metaRedirect.getAttribute('content');
                        const urlMatch = content.match(/url=(.*)/i);
                        if (urlMatch && urlMatch[1]) {
                            window.location.href = urlMatch[1];
                            return;
                        }
                    }
                    
                    document.open();
                    document.write(html);
                    document.close();
                })
                .catch(error => {
                    alert('上传录音文件失败: ' + error);
                    console.error('Error:', error);
                    spinner.classList.add('hidden');
                    if (finalAudioBlob) {
                        updateUploadButton(false, '上传 WebM 录音并开始处理');
                    } else {
                        updateUploadButton(false, '开始提取、校验与声纹分析');
                    }
                });
            }
        });
        
        // 初始状态检查
        if (fileInput.files.length === 0 && finalAudioBlob === null) {
             updateUploadButton(true, '请选择文件或完成录音');
        } else {
             updateUploadButton(false, '开始提取、校验与声纹分析');
        }
        
    </script>
</body>
</html>
"""

CORRECTION_HTML = """
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修正访客信息</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f7f7f7; }
        .input-group label { font-weight: 600; color: #1f2937; }
        .input-group input { border-color: #e5e7eb; border-width: 1px; padding: 0.5rem; border-radius: 0.5rem; width: 100%; }
        .input-group input:focus { border-color: #4f46e5; ring: 2px; ring-color: #4f46e5; }
    </style>
</head>
<body class="p-4 md:p-8 min-h-screen flex items-start justify-center">
    <div class="w-full max-w-2xl bg-white shadow-2xl rounded-xl p-6 md:p-10 space-y-8 border-t-8 border-red-500">
        <h1 class="text-3xl font-extrabold text-gray-900 text-center">⚠️ 数据修正表单 ⚠️</h1>
        
        <div class="p-4 bg-red-50 text-red-700 rounded-lg border border-red-200">
            <p class="font-bold">{{ status }}</p>
            <p class="text-sm mt-1">请核对并修正所有缺失（空值）或校验不通过的字段。修正后的**访客姓名**将用于声纹注册的文件名。</p>
            {% if data_json.voice_match_status_str %}
                <p class="font-semibold mt-2 text-red-600">声纹状态: {{ data_json.voice_match_status_str }}</p>
            {% endif %}
            {% if data_json.validation_log_json and data_json.validation_log_json != '[]' %}
                <h3 class="font-semibold mt-3 text-red-600">字段校验日志：</h3>
                <ul class="list-disc list-inside text-xs mt-1 space-y-0.5">
                    {% for log in data_json.validation_log %}
                        <li>{{ log }}</li>
                    {% endfor %}
                </ul>
            {% endif %}
        </div>

        <form method="POST" action="{{ url_for('save_data') }}" class="space-y-6">
            {% for key, value in fields.items() %}
                <div class="input-group">
                    <label for="{{ key }}" class="block text-sm font-medium text-gray-700 mb-1">
                        {{ key }} 
                        {% if '身份证' in key or '电话' in key or '姓名' in key %}
                            <span class="text-red-500">* (重要字段)</span>
                        {% endif %}
                    </label>
                    <input type="text" name="{{ key }}" id="{{ key }}" value="{{ value }}" 
                        class="mt-1 block w-full shadow-sm sm:text-sm {% if not value %}border-red-400 bg-red-50{% else %}border-gray-300{% endif %} rounded-md"
                        placeholder="{% if not value %}此字段缺失或错误，请重新输入{% elif '身份证' in key %}请输入18位身份证号{% elif '电话' in key %}请输入8-11位数字电话{% else %}请输入修正后的值{% endif %}"
                        {% if key not in ['访客车牌号', '访客车辆类型', '访客单位'] %}required{% endif %}
                    >
                    {% if '姓名' in key and '(' in value %}
                        <p class="text-xs text-gray-500 mt-1">当前拼音备注: {{ value.split('(')[-1].split(')')[0] }}</p>
                    {% endif %}
                </div>
            {% endfor %}

            <input type="hidden" name="voiceprint_mfcc_json" value='{{ data_json.get("voiceprint_mfcc_json", "null") }}'>
            <input type="hidden" name="validation_log_json" value='{{ data_json.get("validation_log_json", "[]") }}'>
            <input type="hidden" name="visitor_pinyin_str" value="{{ data_json.get('visitor_pinyin_str', 'unknown') }}">
            <input type="hidden" name="audio_path_str" value="{{ data_json.get('audio_path_str', '') }}">
            <input type="hidden" name="voiceprint_id_str" value="{{ data_json.get('voiceprint_id_str', '') }}">
            <input type="hidden" name="voice_match_status_str" value="{{ data_json.get('voice_match_status_str', '') }}">


            <button type="submit" 
                class="w-full py-3 px-4 bg-red-600 text-white font-semibold rounded-lg shadow-lg hover:bg-red-700 transition duration-150 ease-in-out"
            >
                保存修正后的数据并执行声纹比对/注册
            </button>
            <a href="{{ url_for('index') }}" class="block text-center mt-4 text-indigo-600 hover:text-indigo-800 transition duration-150">
                返回上传页面
            </a>
        </form>
    </div>
</body>
</html>
"""


if __name__ == '__main__':
    HOST = os.environ.get('HOST', '0.0.0.0') 
    PORT = int(os.environ.get('PORT', 5000)) 
    
    SSL_CERT = 'server.crt'
    SSL_KEY = 'server.key'
    ssl_context = None

    if os.path.exists(SSL_CERT) and os.path.exists(SSL_KEY):
        ssl_context = (SSL_CERT, SSL_KEY)
        print("✅ 检测到证书文件，将以 HTTPS 方式启动。")
    else:
        print("❌ 警告: 找不到 server.crt 或 server.key 文件。请先执行步骤 1 生成证书。将以 HTTP 方式启动。")
    
    try:
        protocol = 'HTTPS' if ssl_context else 'HTTP'
        print(f"尝试在 {protocol} {HOST}:{PORT} 上启动 Flask 应用...")
        print(f"*** 🚀 流程：WebM (浏览器录音) -> 上传 -> WebM文件 (uploads/) -> pydub 转换为 16kHz WAV (临时文件) -> STT -> LLM 处理 ***")

        app.run(
            host=HOST, 
            port=PORT, 
            debug=True,
            ssl_context=ssl_context 
        ) 
    except Exception as e:
        print(f"❌ 启动失败，可能的原因是端口被占用或权限不足。错误: {e}")
