📝 Configuration and Execution Instructions (Revised)
Configure API Keys (LLM / Email):

LLM API: Configure the LLM API key. It is strongly recommended to provide the key by setting the OPENAI_API_KEY environment variable (around line 69 in app.py).

Email Setup: As the application now includes an email sending feature (relying on email_test.py), ensure that all sensitive email configuration details (like SMTP account and password) within email_test.py are safely loaded from environment variables.

Server Setup:

If using HTTPS, please ensure the server (SSL) certificates are correctly configured.

If using HTTP, you can directly modify the if __name__ == '__main__': block in app.py.

Run:

Set up all required environment variables and the environment, then run app.py.


配置 API 密钥 (LLM/邮件):

LLM API: 配置 LLM API 密钥。强烈建议通过设置 OPENAI_API_KEY 环境变量来提供密钥（位于 app.py 第 69 行附近）。

邮件发送: 由于应用引入了邮件发送功能（依赖 email_test.py），请确保在 email_test.py 中配置的 SMTP 账号、密码等敏感信息也是通过环境变量安全加载的。

服务器设置:

如果使用 HTTPS，请自行配置好服务器证书（SSL 证书：server.crt 和 server.key）。

如果使用 HTTP，可以直接修改 app.py 的 if __name__ == '__main__': 块。

运行:

配置好所有必需的环境变量和环境后，运行 app.py。